
require('dotenv').config();  // this line is important!

const {DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_DIALECT, DB_ALIAS } = process.env;

module.exports = {
  "development": {
    "username": process.env.DB_USERNAME,
    "password": process.env.DB_PASSWORD,
    "database": process.env.DB_DATABASE,
    "host": process.env.DB_HOSTNAME,
    "dialect": process.env.DB_DIALECT,
    "operatorsAliases": process.env.DB_ALIAS
  },
  "test": {
    "username": process.env.DB_USERNAME,
    "password": process.env.DB_PASSWORD,
    "database": process.env.DB_DATABASE,
    "host": process.env.DB_HOSTNAME,
    "dialect": process.env.DB_DIALECT,
    "operatorsAliases": process.env.DB_ALIAS
  },
  "production": {
    "username": process.env.DB_USERNAME,
    "password": process.env.PASSWORD,
    "database": process.env.DB_DATABASEE,
    "host": process.env.DB_HOSTNAME,
    "dialect": process.env.DB_DIALECT,
    "operatorsAliases": process.env.DB_ALIAS
  }
}
